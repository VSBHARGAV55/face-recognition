Our product can be run through app.py.

The scripts to train the models are facenet-NN.py and facenet-SVM.py.

Models we trained can be accessed here:
https://drive.google.com/open?id=1cmgKPI9JOta51lpf6G82YROhZYfg0k7-

The scripts for other algorithms we tried are also in .ipynb files.

Click below for the VIDEO:

[![Watch the video](https://img.youtube.com/vi/NcOfYoMvib8/sddefault.jpg)](https://youtu.be/NcOfYoMvib8)
